/*
 * Author: Tomas Nozicka
 */

#pragma once


namespace SuperiorMySqlpp
{
    /*
     * TODO: Add support for reasonable amount of types
     */
}
